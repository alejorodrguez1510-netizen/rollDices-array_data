/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraydata;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayData {

    public static void mainMenu() {
        System.out.println("\n::: MAIN MENU :::");
        System.out.println("[1]. Create/Register User");
        System.out.println("[2]. List Users");
        System.out.println("[3]. Search User");
        System.out.println("[4]. Update User");
        System.out.println("[5]. Delete User");
        System.out.println("[6]. Exit");
        System.out.print("Press an option: ");
    }

    public static void main(String[] args) {

        Scanner data = new Scanner(System.in);

        ArrayList<String> identNumbers = new ArrayList<>();
        ArrayList<String> firstNames = new ArrayList<>();
        ArrayList<String> lastNames = new ArrayList<>();
        ArrayList<String> emails = new ArrayList<>();
        ArrayList<Integer> ages = new ArrayList<>();

        String ident_number;
        String firstname;
        String lastname;
        String email;
        String key;

        int age;
        int opt;

        boolean menu_status = true;

        while (menu_status) {

            mainMenu();

            opt = data.nextInt();
            data.nextLine();

            switch (opt) {

                case 1:

                    System.out.println("\n::: REGISTER NEW USER :::");
                    System.out.println("User Nro: " + (firstNames.size() + 1));

                    System.out.print("Identification Number: ");
                    ident_number = data.nextLine();

                    boolean existsId = false;

                    for (int j = 0; j < identNumbers.size(); j++) {
                        if (identNumbers.get(j).equals(ident_number)) {
                            existsId = true;
                        }
                    }

                    if (existsId) {
                        System.out.println("Identification number already exists.");
                        System.out.println("\nPress ENTER to continue...");
                        key = data.nextLine();
                        break;
                    }

                    System.out.print("First Name: ");
                    firstname = data.nextLine();

                    System.out.print("Last Name: ");
                    lastname = data.nextLine();

                    System.out.print("Email: ");
                    email = data.nextLine();

                    boolean existsEmail = false;

                    for (int j = 0; j < emails.size(); j++) {
                        if (emails.get(j).equalsIgnoreCase(email)) {
                            existsEmail = true;
                        }
                    }

                    if (existsEmail) {
                        System.out.println("Email already exists.");
                        System.out.println("\nPress ENTER to continue...");
                        key = data.nextLine();
                        break;
                    }

                    System.out.print("Age: ");
                    age = data.nextInt();
                    data.nextLine();

                    identNumbers.add(ident_number);
                    firstNames.add(firstname);
                    lastNames.add(lastname);
                    emails.add(email);
                    ages.add(age);

                    System.out.println("\nUser registered successfully!");

                    System.out.println("\nPress ENTER to continue...");
                    key = data.nextLine();

                    break;

                case 2:

                    System.out.println("\n::: USER LIST :::");

                    if (firstNames.size() == 0) {

                        System.out.println("No users registered.");

                    } else {

                        System.out.println("Total Users: " + firstNames.size());

                        for (int j = 0; j < firstNames.size(); j++) {

                            System.out.println("\nUser " + (j + 1));
                            System.out.println("ID: " + identNumbers.get(j));
                            System.out.println("Name: " + firstNames.get(j));
                            System.out.println("Last Name: " + lastNames.get(j));
                            System.out.println("Email: " + emails.get(j));
                            System.out.println("Age: " + ages.get(j));
                        }
                    }

                    System.out.println("\nPress ENTER to continue...");
                    key = data.nextLine();

                    break;

                case 3:

                    System.out.println("\n::: SEARCH USER :::");

                    System.out.print("Identification Number: ");
                    ident_number = data.nextLine();

                    boolean found = false;

                    for (int j = 0; j < identNumbers.size(); j++) {

                        if (identNumbers.get(j).equals(ident_number)) {

                            System.out.println("\nUSER FOUND");
                            System.out.println("ID: " + identNumbers.get(j));
                            System.out.println("Name: " + firstNames.get(j));
                            System.out.println("Last Name: " + lastNames.get(j));
                            System.out.println("Email: " + emails.get(j));
                            System.out.println("Age: " + ages.get(j));

                            found = true;
                            break;
                        }
                    }

                    if (found == false) {
                        System.out.println("User not found.");
                    }

                    System.out.println("\nPress ENTER to continue...");
                    key = data.nextLine();

                    break;

                case 4:

                    System.out.println("\n::: UPDATE USER :::");

                    System.out.print("Identification Number: ");
                    ident_number = data.nextLine();

                    found = false;

                    for (int j = 0; j < identNumbers.size(); j++) {

                        if (identNumbers.get(j).equals(ident_number)) {

                            System.out.print("New First Name: ");
                            firstname = data.nextLine();

                            System.out.print("New Last Name: ");
                            lastname = data.nextLine();

                            System.out.print("New Email: ");
                            email = data.nextLine();

                            boolean emailExists = false;

                            for (int k = 0; k < emails.size(); k++) {

                                if (k != j && emails.get(k).equalsIgnoreCase(email)) {
                                    emailExists = true;
                                }
                            }

                            if (emailExists) {
                                System.out.println("Email already exists.");
                                found = true;
                                break;
                            }

                            System.out.print("New Age: ");
                            age = data.nextInt();
                            data.nextLine();

                            firstNames.set(j, firstname);
                            lastNames.set(j, lastname);
                            emails.set(j, email);
                            ages.set(j, age);

                            System.out.println("User updated successfully.");

                            found = true;
                            break;
                        }
                    }

                    if (found == false) {
                        System.out.println("User not found.");
                    }

                    System.out.println("\nPress ENTER to continue...");
                    key = data.nextLine();

                    break;

                case 5:

                    System.out.println("\n::: DELETE USER :::");

                    System.out.print("Identification Number: ");
                    ident_number = data.nextLine();

                    found = false;

                    for (int j = 0; j < identNumbers.size(); j++) {

                        if (identNumbers.get(j).equals(ident_number)) {

                            identNumbers.remove(j);
                            firstNames.remove(j);
                            lastNames.remove(j);
                            emails.remove(j);
                            ages.remove(j);

                            System.out.println("User deleted successfully.");

                            found = true;
                            break;
                        }
                    }

                    if (found == false) {
                        System.out.println("User not found.");
                    }

                    System.out.println("\nPress ENTER to continue...");
                    key = data.nextLine();

                    break;

                case 6:

                    System.out.println("\nBye Bye...");
                    menu_status = false;

                    break;

                default:

                    System.out.println("Invalid option.");

                    break;
            }
        }

        data.close();
    }
}